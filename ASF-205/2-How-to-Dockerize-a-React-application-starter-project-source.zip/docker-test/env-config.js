window._env_ = {
  TEST_ENV_VARIABLE: "This is the value",
}
